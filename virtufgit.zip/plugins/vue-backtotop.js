import Vue from 'vue'
import BackToTop from 'vue-backtotop'

Vue.use(BackToTop)