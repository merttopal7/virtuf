<template>
    <div class="author-info" data-aos="fade-up" data-aos-duration="1000">
        <div class="thumb">
            <img src="/images/blog/author-01.jpg" alt="Image">
        </div>
        <div class="author-details">
            <h4 class="title">Marcella Moody</h4>
            <img class="line-shape" src="/images/shape/line-s1.png" alt="image">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industr standard dummy text ever since the 1500swhean an unknown printer took an galley of type and scrambled.</p>
            <div class="social-icons">
                <a href="#"><i class="icofont-facebook"></i></a>
                <a href="#"><i class="icofont-skype"></i></a>
                <a href="#"><i class="icofont-instagram"></i></a>
            </div>
        </div>
    </div>
</template>