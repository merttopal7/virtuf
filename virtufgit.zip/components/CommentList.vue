<template>
    <div class="comment-content" data-aos="fade-up" data-aos-duration="1000">
        <div class="single-comment">
            <div class="author-info">
                <div class="thumb">
                    <img src="/images/blog/c1.jpg" alt="Image">
                </div>
                <div class="author-details">
                    <h4 class="name">Marcella Moody</h4>
                    <img class="line-shape" src="/images/shape/line-s1.png" alt="image">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled.</p>
                    <button class="btn-reply"><i class="icofont-reply"></i> Reply</button>
                </div>
                <div class="comment-date">07 Jan, 2021</div>
            </div>
        </div>
        <div class="single-comment pl-xxs-30 pl-70">
            <div class="author-info">
                <div class="thumb">
                    <img src="/images/blog/c2.jpg" alt="Image">
                </div>
                <div class="author-details">
                    <h4 class="name">Jan Roberts</h4>
                    <img class="line-shape" src="/images/shape/line-s1.png" alt="image">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled.</p>
                    <button class="btn-reply"><i class="icofont-reply"></i> Reply</button>
                </div>
                <div class="comment-date">15 Mar, 2021</div>
            </div>
        </div>
        <div class="single-comment">
            <div class="author-info">
                <div class="thumb">
                    <img src="/images/blog/c3.jpg" alt="Image">
                </div>
                <div class="author-details">
                    <h4 class="name">Kristy Kelly</h4>
                    <img class="line-shape" src="/images/shape/line-s1.png" alt="image">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled.</p>
                    <button class="btn-reply"><i class="icofont-reply"></i> Reply</button>
                </div>
                <div class="comment-date">24 Sep, 2021</div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    };
</script>