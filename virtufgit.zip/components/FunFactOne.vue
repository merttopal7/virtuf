<template>
    <section class="funfact-area funfact-default-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-10 col-md-6 col-lg-5 offset-lg-1 col-xl-5 offset-xl-1">
                    <div class="section-title xs-text-center" data-aos="fade-up" data-aos-duration="1000">
                        <h2 class="title">Successfully Complete <span class="text-theme-color bottom-style">2,500</span> Project.</h2>
                        <n-link to="/service" class="btn btn-theme btn-border">
                            Our Services <i class="icon icofont-long-arrow-right"></i>
                        </n-link>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-4 offset-xl-1">
                    <div class="row funfact-items-style1">
                        <div class="col-6 col-sm-6">
                            <div class="funfact-item mt-20" data-aos="fade-up" data-aos-duration="1000">
                                <div class="number">
                                    <h2><span class="counter-animate">98</span>+</h2>
                                </div>
                                <p class="title">Team Member</p>
                            </div>
                        </div>
                        <div class="col-6 col-sm-6">
                            <div class="funfact-item" data-aos="fade-up" data-aos-duration="1000">
                                <div class="number">
                                    <h2><span class="counter-animate">2,500</span></h2>
                                </div>
                                <p class="title">Complete Project</p>
                            </div>
                        </div>
                        <div class="col-6 col-sm-6">
                            <div class="funfact-item mt-20" data-aos="fade-up" data-aos-duration="1200">
                                <div class="number">
                                    <h2><span class="counter-animate">895</span></h2>
                                </div>
                                <p class="title">Cup of Coffee</p>
                            </div>
                        </div>
                        <div class="col-6 col-sm-6">
                            <div class="funfact-item" data-aos="fade-up" data-aos-duration="1200">
                                <div class="number">
                                    <h2><span class="counter-animate">78</span>k</h2>
                                </div>
                                <p class="title">Happy Clients</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shape-line-style"></div>
    </section>
</template>

<script>
    export default {

    };
</script>

<style lang="scss" scoped>

</style>