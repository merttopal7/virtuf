<template>
    <div>
        <Nuxt />
    </div>
</template>
